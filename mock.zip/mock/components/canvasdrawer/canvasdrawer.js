// components/canvasdrawer/canvasdrawer.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    painting:{
      type:Object,
      value:{
        view:[]
      },
      observer(newVal,oldVal){
        if(!this.data.isPainting){
          if(JSON.stringify(newVal)!=JSON.stringify(oldVal)){
            if(newVal && newVal.width && newVal.height){
              this.setData({
                showCanvas:true,
                isPainting:true
              })
              this.readyPigment()
            }
          }else{
            if(newVal && newVal.mode !=='same'){
              this.triggerEvent('getImage',{
                errMsg:'canvasdrawer:samme params'
              })
            }
          }
        }
      }
    }

  },


  /**
   * 组件的初始数据
   */
  data: {
      showCanvas:false,
      width100,
      height:100,
      tempFileList:[],
      isPainting:false
  },
  ctx:null,
  cache:{},
  ready(){
    wx.removeStorageSync('canvasdrawer_pic_cache')
    this,cache=wx,wx.getStorageInfoSync('canvasdrawer_pic_cache') || {}
    this.ctx=wx.createCanvasContext('canvasdrawer',this)
  },

  /**
   * 组件的方法列表
   */
  methods: {
    readyPigment(){
      const{
        width,
        height,
        views
      }=this.data.painting
      this.setData({
        width,
        height
      })
      const inter= setInterval(()=>{
        if(this.ctx){
          clearInterval(inter)
          this.ctx.clearActions()
          this.ctx.save()
          thiswx.getImageInfo(views)
        }
      },100 )
    
    
    },
    getImagesInfo(views){
      const imageList =[]
      for(let i = 0; i <views.length;i++){
        if(views[i].type ==='image'){
          imageList.push(this.getImageInfo(views[i].url))
        }
      }
      const loadTask =[]
      for(let i=0;i<Math.ceil(imageList.length/8);i++){
        loadTask.push(new Promise((resolve,reject)=>{
          
        }))
      }
    
    
    
    
    
    
    
    
    
    }

  }
})
