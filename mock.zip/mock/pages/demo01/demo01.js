// pages/demo01/demo01.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg:"hellow",
    num:1000,
    list:[
      {
        id:0,
        name:"zhubajie"
      },
      {
        id:1,
        name:"天蓬元帅"
      },
      {
        id:2,
        name:"孙悟空"
      }
    ]
    
  },

});